---
title: PressBooks
taxonomy:
    category: docs
---

### Using

# PressBooks


Pressbooks is an open source content management system designed for creating books. It is based on WordPress, and can export content in many formats for ebooks, webbooks or print.

!!! Consider using Pressbooks for your course content (lecture notes, asynchronous learning activities, etc.), or for assignments such as collaborative group projects, sharing writing assignments, etc.
