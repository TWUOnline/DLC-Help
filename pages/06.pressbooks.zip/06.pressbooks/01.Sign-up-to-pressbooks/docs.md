---
title: Sign Up to PressBooks
taxonomy:
    category: docs
child_type: docs
---

#### To begin, go to [books.twu.ca](books.twu.ca) and click the **Register** button

![](pressbooks-signin.PNG)

#### Enter your username, email and password in the fields provided, and click **Next**

![](pressbooks-user-info.PNG)

#### Lastly, enter the Webbook Address and the Book title, and click the **Create Book** button.

![](create-pressbook.PNG)
