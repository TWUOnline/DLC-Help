---
title: Export
taxonomy:
    category: docs
child_type: docs
---

#### You can export your book in different formats. To do so, click **"Export"** on the menu located on the left hand side of the screen

![](export1.png)

#### Check the box of your preferred format.

#### Then, click the **"Export Your Book"** button.

#### The exported file will be displayed under the **"Latest Exports"** section. Hover over the file and click **"Download"**

![](export3.png)
